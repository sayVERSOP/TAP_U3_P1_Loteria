
import java.awt.Image;
import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author david
 */


public class BarajaHilo extends Thread{
    
    private final String[] CARTAS = {
    "1 - EL GALLO","2 - EL DIABLITO","3 - LA DAMA","4 - EL CATRÍN","5 - EL PARAGUAS",
    "6 - LA SIRENA","7 - LA ESCALERA","8 - LA BOTELLA","9 - EL BARRIL","10 - EL ARBOL",
    "11 - EL MELÓN","12 - EL VALIENTE","13 - EL GORRITO","14 - LA MUERTE","15 - LA PERA",
    "16 - LA BANDERA","17 - EL BANDOLÓN","18 - EL VIOLONCELLO","19 - LA GARZA","20 - EL PAJARO",
    "21 - LA MANO","22 - LA BOTA","23 - LA LUNA","24 - EL COTORRO","25 - EL BORRACHO",
    "26 - EL NEGRITO","27 - EL CORAZON","28 - LA SANDIA","29 - EL TAMBOR","30 - EL CAMARÓN",
    "31 - LAS JARAS","32 - EL MÚSICO","33 - LA ARAÑA","34 - EL SOLDADO","35 - LA ESTRELLA",
    "36 - EL CAZO","37 - EL MUNDO","38 - EL APACHE","39 - EL NOPAL","40 - EL ALACRÁN",
    "41 - LA ROSA","42 - LA CALAVERA","43 - LA CAMPANA","44 - EL CANTARITO","45 - EL VENADO",
    "46 - EL SOL","47 - LA CORONA","48 - LA CHALUPA","49 - EL PINO","50 - EL PESCADO",
    "51 - LA PALMA","52 - LA MACETA","53 - EL ARPA","54 - LA RANA"};
    
    private final Ventana val;
    private final boolean[] CARTAS_MOSTRADAS = new boolean[54];
    private boolean ejecutar = true;
    public boolean buenas = false;
    private int contador = 0;
    
    
    
    public BarajaHilo(Ventana v){//********************************************
                val = v;

        for (int i = 0; i < CARTAS_MOSTRADAS.length; i++) {
            CARTAS_MOSTRADAS[i] = false;
            int n = i+1;
        }
    }//*************************************************************************
    
    
    
    @Override
    public void run() {
        super.run(); //To change body of generated methods, choose Tools | Templates.
        while(ejecutar){
            int b = baraja();
            saltear(CARTAS[b]);
           val.modelo.addElement(CARTAS[b]);

            contador++;
            System.out.println(contador);
            dormir(2300);
            if (buenas) {
               CartasRestantes();
            }
            if (contador >= 54) {
                ejecutar = false;
                val.lblTitulo.setText("GAME OVER");

            }
            dormir(50);
        }
    }
    
    private int baraja(){
        int n = (int) (Math.random()*54);
        if (CARTAS_MOSTRADAS[n]) {
            return baraja();
        }
        CARTAS_MOSTRADAS[n] = true;
        return n;
    }
    
    private void CartasRestantes(){
        
       val.lblTitulo.setText("REVISION DE CARTAS RESTANTES");

            dormir(1000);
            while(!(contador >= 54)){
            int b = baraja();
            
            saltear(CARTAS[b]);
            val.modelo.addElement(CARTAS[b]);

            contador++;
            System.out.println(contador);
            dormir(2000);
        }
    }
    
    public void saltear(String cad){
        ImageIcon imIcono = new ImageIcon(getClass().getResource("imagenes/" + cad + ".png"));
        
        Image imagen = imIcono.getImage().getScaledInstance(
                189, 
                300, 
                Image.SCALE_SMOOTH);
        
        Icon carta = new ImageIcon(imagen);
             val.lblCarta.setIcon(carta);
             

    }
    
    private void dormir(int e){
        try {
            sleep(e);
        } catch (InterruptedException ex) {
            Logger.getLogger(BarajaHilo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
}
