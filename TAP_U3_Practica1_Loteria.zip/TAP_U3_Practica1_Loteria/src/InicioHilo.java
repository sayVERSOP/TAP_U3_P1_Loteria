
import java.awt.Image;
import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author david
 */
public class InicioHilo extends Thread{
    private final Ventana val;
    private final boolean ejecutar = true;
    private boolean cambiador = true;
    
    
    
    public InicioHilo(Ventana v){
        val = v;
    }

    @Override
    public void run() {
        super.run(); //To change body of generated methods, choose Tools | Templates.
        
        try {
            
            
            while(ejecutar){
                int n = (int) (Math.random()*500)+100;
                
                
                sleep(n);
                
            }//While
        } catch (InterruptedException ex) {
            Logger.getLogger(InicioHilo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    private void saltear(String cad, JLabel lbl){
        ImageIcon imIcono = new ImageIcon(getClass().getResource("imagenes/" + cad + ".png"));
        Image imagen = imIcono.getImage().getScaledInstance(
                100, 
                100, 
                
                Image.SCALE_SMOOTH);
        
        Icon carta = new ImageIcon(imagen);
        lbl.setIcon(carta);
    }
    
}
